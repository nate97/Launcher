

class FoodBeltBase:
    NumFoodNodes = 4
