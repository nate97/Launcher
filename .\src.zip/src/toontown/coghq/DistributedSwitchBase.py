

def stubFunction(*args):
    pass


class DistributedSwitchBase:
    pass
