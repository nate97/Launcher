from .SpecImports import *
BattleCells = {}
CogData = []
ReserveCogData = []
