Down = 0
Up = 1

def oppositeState(state):
    if state is Down:
        return Up
    else:
        return Down
