from direct.directnotify import DirectNotifyGlobal
from direct.task import Task
from . import DistributedSwitchAI

class DistributedTriggerAI(DistributedSwitchAI.DistributedSwitchAI):
    pass
