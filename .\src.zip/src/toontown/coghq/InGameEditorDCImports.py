if __dev__:
    from direct.directutil import DistributedLargeBlobSender
    from . import DistributedInGameEditor
