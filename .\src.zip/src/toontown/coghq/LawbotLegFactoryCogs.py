from .SpecImports import *
LobbyParent = 10014
LobbyCell = 0
BattleCells = {}
ReserveCogData = []
CogData = []
