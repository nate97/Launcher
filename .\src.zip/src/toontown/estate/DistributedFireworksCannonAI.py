from direct.directnotify import DirectNotifyGlobal
from toontown.effects.DistributedFireworkShowAI import DistributedFireworkShowAI

class DistributedFireworksCannonAI(DistributedFireworkShowAI):
    notify = DirectNotifyGlobal.directNotify.newCategory("DistributedFireworksCannonAI")

    def avatarEnter(self):
        pass

    def avatarExit(self):
        pass

    def freeAvatar(self):
        pass

    def setMovie(self, todo0, todo1, todo2):
        pass

    def setPosition(self, todo0, todo1, todo2):
        pass

