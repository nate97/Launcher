from toontown.town import Street


class TTStreet(Street.Street):
    pass