from toontown.town import Street


class DLStreet(Street.Street):
    pass