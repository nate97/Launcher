from toontown.town import Street


class MMStreet(Street.Street):
    pass