from toontown.town import Street


class DGStreet(Street.Street):
    pass