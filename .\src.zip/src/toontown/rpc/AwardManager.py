from direct.distributed.DistributedObjectGlobal import DistributedObjectGlobal

class AwardManager(DistributedObjectGlobal):
    pass
